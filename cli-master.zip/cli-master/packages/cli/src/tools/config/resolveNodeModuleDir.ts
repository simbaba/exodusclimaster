import {resolveNodeModuleDir} from '@react-native-community/cli-tools';
export default resolveNodeModuleDir;
