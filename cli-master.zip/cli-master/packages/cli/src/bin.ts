#!/usr/bin/env node

import './tools/gracefulifyFs';

import {run} from './';

run();
