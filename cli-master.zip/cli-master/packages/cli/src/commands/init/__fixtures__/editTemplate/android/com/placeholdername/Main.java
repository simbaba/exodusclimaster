com.placeholdername;

public static class Main {
  public static void run() {
    String name = "PlaceholderName";
    String title = "Hello App Display Name";
  }
}
