# React Native CLI

Command line tools to interact with React Native projects.

This package contains source code for `@react-native-community/cli`, the actual CLI that comes bundled with React Native. You don't need to install it separately in your project.

See the [list of available commands](../../docs/commands.md).
