import logAndroid from './logAndroid';
import runAndroid from './runAndroid';

export default [logAndroid, runAndroid];
