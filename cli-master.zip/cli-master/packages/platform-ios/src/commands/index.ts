import logIOS from './logIOS';
import runIOS from './runIOS';

export default [logIOS, runIOS];
