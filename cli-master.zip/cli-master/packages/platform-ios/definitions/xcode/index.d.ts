declare module 'xcode' {
  const module: any;

  export default module;
}
