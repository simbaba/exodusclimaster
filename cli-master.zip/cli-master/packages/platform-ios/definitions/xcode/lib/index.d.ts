declare module 'xcode/lib/pbxFile' {
  const module: any;

  export default module;
}
